export default [
  {
    id: 'U001',
    name: 'Alice Example',
    email: 'alice@example.com',
    // password: password123
    password: '$2b$10$vEtfjjKOjVbAb25/vQoLG.q0ALzfo7kFf5wAW/cc/NPZMpbGXk3n6',
  },
  {
    id: 'U002',
    name: 'Bob Sample',
    email: 'bob@example.com',
    // password: secret456
    password: '$2b$10$UEbBeRopzGVW/FfewliPP.5QmBibZ1jYG01omC.auzicQn931ovfG',
  },
  {
    id: 'U003',
    name: 'Cara Admin',
    email: 'cara@example.com',
    // password: admin
    password: '$2b$10$nMU8jle1WZOq3CgKgmmkI.NnI4J4CGxh/XKqTeoNCy5E3Ea31oszi',
  },
];